const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const bcrypt = require("bcryptjs"); // Necesitarás instalar bcryptjs para el hash de contraseñas
const app = express();

// Configuración de la conexión a la base de datos
const con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "n0m3l0",
    database: "PanaderiaLaDesesperanza"
});

// Conectar a la base de datos y manejar errores de conexión
con.connect((err) => {
    if (err) {
        console.error("Error al conectar a la base de datos:", err);
        process.exit(1);
    }
    console.log("Conexión exitosa a la base de datos");
});

// Configuración de middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public")); // Carpeta para archivos front-end (HTML, CSS, JS)

// Ruta para servir el index.html
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Validación de nombre (solo letras)
const validarNombre = (nombre) => /^[a-zA-Z\s]+$/.test(nombre);

// Validación de contraseña (mínimo 8 caracteres, al menos 1 número, 1 mayúscula)
const validarContraseña = (contraseña) => /^(?=.*\d)(?=.*[A-Z]).{8,}$/.test(contraseña);

// Ruta de registro
app.post("/registro", (req, res) => {
    const { nombre, email, contraseña, confirmarContraseña } = req.body;

    if (!nombre || !email || !contraseña || !confirmarContraseña) {
        return res.status(400).send("Por favor, completa todos los campos.");
    }

    if (!validarNombre(nombre)) {
        return res.status(400).send("El nombre solo puede contener letras.");
    }

    if (!validarContraseña(contraseña)) {
        return res.status(400).send("La contraseña debe tener al menos 8 caracteres, una mayúscula y un número.");
    }

    if (contraseña !== confirmarContraseña) {
        return res.status(400).send("Las contraseñas no coinciden.");
    }

    // Verificar si el email ya está registrado
    con.query("SELECT * FROM Usuarios WHERE email = ?", [email], (err, resultados) => {
        if (err) {
            console.error("Error al verificar el email:", err);
            return res.status(500).send("Error al verificar el email.");
        }

        if (resultados.length > 0) {
            return res.status(400).send("El email ya está registrado.");
        }

        // Hash de la contraseña
        bcrypt.hash(contraseña, 10, (err, hash) => {
            if (err) {
                console.error("Error al cifrar la contraseña:", err);
                return res.status(500).send("Error al cifrar la contraseña.");
            }

            // Insertar el nuevo usuario en la base de datos
            const query = "INSERT INTO Usuarios (nombre, email, contraseña, rol) VALUES (?, ?, ?, ?)";
            con.query(query, [nombre, email, hash, 'cliente'], (err, result) => {
                if (err) {
                    console.error("Error al registrar el usuario:", err);
                    return res.status(500).send("Error al registrar el usuario.");
                }

                res.send("Usuario registrado correctamente.");
            });
        });
    });
});

// Ruta de inicio de sesión
app.post("/login", (req, res) => {
    const { email, contraseña } = req.body;

    if (!email || !contraseña) {
        return res.status(400).send("Por favor, ingresa tu correo y contraseña.");
    }

    // Verificar si el email existe
    con.query("SELECT * FROM Usuarios WHERE email = ?", [email], (err, resultados) => {
        if (err) {
            console.error("Error al verificar el email:", err);
            return res.status(500).send("Error al verificar el email.");
        }

        if (resultados.length === 0) {
            return res.status(400).send("Correo electrónico o contraseña incorrectos.");
        }

        const usuario = resultados[0];

        // Comparar la contraseña proporcionada con la almacenada
        bcrypt.compare(contraseña, usuario.contraseña, (err, esValido) => {
            if (err) {
                console.error("Error al comparar contraseñas:", err);
                return res.status(500).send("Error al verificar la contraseña.");
            }

            if (!esValido) {
                return res.status(400).send("Correo electrónico o contraseña incorrectos.");
            }

            // Si la contraseña es válida, podemos devolver los datos del usuario
            res.json({
                usuario_id: usuario.usuario_id,
                nombre: usuario.nombre,
                email: usuario.email,
                rol: usuario.rol
            });
        });
    });
});
// Ruta de registro
app.post("/registro", (req, res) => {
    const { nombre, email, contraseña, confirmarContraseña } = req.body;

    // Validación de campos vacíos
    if (!nombre || !email || !contraseña || !confirmarContraseña) {
        return res.status(400).send("Por favor, completa todos los campos.");
    }

    // Validación de nombre (solo letras)
    if (!validarNombre(nombre)) {
        return res.status(400).send("El nombre solo puede contener letras.");
    }

    // Validación de contraseña (mínimo 8 caracteres, 1 mayúscula, 1 número)
    if (!validarContraseña(contraseña)) {
        return res.status(400).send("La contraseña debe tener al menos 8 caracteres, una mayúscula y un número.");
    }

    // Verificar que las contraseñas coincidan
    if (contraseña !== confirmarContraseña) {
        return res.status(400).send("Las contraseñas no coinciden.");
    }

    // Verificar si el email ya está registrado
    con.query("SELECT * FROM Usuarios WHERE email = ?", [email], (err, resultados) => {
        if (err) {
            console.error("Error al verificar el email:", err);
            return res.status(500).send("Error al verificar el email.");
        }

        if (resultados.length > 0) {
            return res.status(400).send("El email ya está registrado.");
        }

        // Hash de la contraseña
        bcrypt.hash(contraseña, 10, (err, hash) => {
            if (err) {
                console.error("Error al cifrar la contraseña:", err);
                return res.status(500).send("Error al cifrar la contraseña.");
            }

            // Insertar el nuevo usuario en la base de datos
            const query = "INSERT INTO Usuarios (nombre, email, contraseña, rol) VALUES (?, ?, ?, ?)";
            con.query(query, [nombre, email, hash, 'cliente'], (err, result) => {
                if (err) {
                    console.error("Error al registrar el usuario:", err);
                    return res.status(500).send("Error al registrar el usuario.");
                }

                res.send("Usuario registrado correctamente.");
            });
        });
    });
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log("Servidor ejecutándose en http://localhost:3000");
});
